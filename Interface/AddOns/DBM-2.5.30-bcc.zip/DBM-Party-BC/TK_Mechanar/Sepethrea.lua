local mod = DBM:NewMod(564, "DBM-Party-BC", 13, 258)
local L = mod:GetLocalizedStrings()

mod:SetRevision("20210605024644")
mod:SetCreatureID(19221)
mod:SetEncounterID(1930)
mod:SetModelID(19166)
mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
)
