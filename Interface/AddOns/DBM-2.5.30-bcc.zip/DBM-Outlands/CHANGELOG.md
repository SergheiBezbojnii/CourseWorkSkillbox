# <DBM> Outlands

## [2.5.30](https://github.com/DeadlyBossMods/DBM-TBC-Classic/tree/2.5.30) (2022-03-22)
[Full Changelog](https://github.com/DeadlyBossMods/DBM-TBC-Classic/compare/2.5.29...2.5.30) [Previous Releases](https://github.com/DeadlyBossMods/DBM-TBC-Classic/releases)

- prep new retail and tbc tags  
- bump BCC toc Raise boss unit ID scan to boss 10, per hotfix last week, now allows up to 10 and all return valid unit events  
- bump BCC toc  
- Update koKR (#90)  
- revise tanking check with a new option to only request status 3 check  
- Update localization.cn.lua (#89)  
- add a you pos count object.  
- Update commonlocal.cn.lua (#88)  
- Update localization.tw.lua (#87)  
- Update commonlocal.tw.lua (#86)  
- Update alpha revision  
- prep new tag for retail  
- Find and report duplicate entries (usually typos in objects that cause problems)  
- Update commonlocal.ru.lua (#83) Add one phrase. Small cleaning.  
- Update koKR (#84)  
- Add count variant of tank combo  
- swear i copy/pasted that  
- set new alpha revision  
- prep fresh retail tag  
- Closing out another feature request. It's now possible to set pull timer countdown voice seperately from regular countdown options.  
- bump alpha  
- ready new release now that LFR updated, changed bosses updated, and last 3 updated. :)  
- Update localization.fr.lua (#79)  
- support up to 8 boss unit ids, apparently 6-8 were added in 9.2?  
- Update localization.cn.lua (#82)  
- bump alpha, again  
- prep new tag, no revision update  
- bumped alpha version (aka tomorrows release with fridays hotfixes probably :D)  
- prep new retail tag  
- bump alpha  
- Bump version and ready new retail tag  
- prep next cycle  
- Fix missing comma on shadowlands outdoor addition  
- Fix up sounds for BCC/Classic based on accurate SoundKitID's  
- Update localization.ru.lua (#80) So correct.  
- Kill off extended raid icons feature, blizzard broke it in recent builds (predicted they would, but hoped they'd actually finish feature instead, was wishful thinking I suppose)  
- bump alphas  
