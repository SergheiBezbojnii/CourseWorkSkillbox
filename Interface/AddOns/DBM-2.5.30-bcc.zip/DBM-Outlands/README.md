[![Build Status](https://github.com/DeadlyBossMods/DBM-Unified/workflows/CI/badge.svg)](https://github.com/DeadlyBossMods/DBM-Unified/actions?workflow=CI)
[![DeadlyBossMods on Discord](https://img.shields.io/badge/discord-DeadlyBossMods-738bd7.svg?style=flat)](https://discord.gg/DeadlyBossMods)

[![Patreon](https://media.forgecdn.net/attachments/76/25/patreon-medium-button.png)](https://patreon.com/deadlybossmods)

# Deadly Boss Mods - Unified codebase
The purpose of this codebase is a "unification" of the Core, GUI, and StatusBarTimers across all 3 versions of the game.
