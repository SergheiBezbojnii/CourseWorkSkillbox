local mod	= DBM:NewMod("DeathswornCaptain", "DBM-Party-Classic", 14)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20210401042132")
mod:SetCreatureID(3872)

mod:RegisterCombat("combat")
