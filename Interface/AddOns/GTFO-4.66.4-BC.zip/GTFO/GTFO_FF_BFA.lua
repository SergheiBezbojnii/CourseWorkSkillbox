--------------------------------------------------------------------------
-- GTFO_FF_BFA.lua 
--------------------------------------------------------------------------
--[[
GTFO Friendly Fire List - Battle for Azeroth
]]--

if (not (GTFO.ClassicMode or GTFO.BurningCrusadeMode)) then

-- **********************
-- * Battle for Azeroth *
-- **********************


GTFO.FFSpellID["291338"] = {
  --desc = "Blooddrinker (Madness: Bloodthirsty)";
  sound = 4;
};


end
