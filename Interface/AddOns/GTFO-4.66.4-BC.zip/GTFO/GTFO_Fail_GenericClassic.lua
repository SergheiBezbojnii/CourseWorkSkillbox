--------------------------------------------------------------------------
-- GTFO_Fail_GenericClassic.lua 
--------------------------------------------------------------------------
--[[
GTFO Fail List - Generic (Classic version)
]]--

--if (GTFO.ClassicMode) then

--end
