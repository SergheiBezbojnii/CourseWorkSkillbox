--------------------------------------------------------------------------
-- GTFO_FF_SL.lua 
--------------------------------------------------------------------------
--[[
GTFO Friendly Fire List - Shadowlands
]]--

if (not (GTFO.ClassicMode or GTFO.BurningCrusadeMode)) then

-- ***************
-- * Shadowlands *
-- ***************

end
