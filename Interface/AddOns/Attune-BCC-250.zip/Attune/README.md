Attune
by Cixi@Remulos (Classic Oceanic)


WHAT THE ADDON IS FOR:
  Attune is there to collect your current attunement progress, and character information (class/race/etc) and allow you to upload that information to the WarcraftRatings website
  The Website will then allow you to display/edit/share your attunement progress with others/guildies
  The uploaded profiles can be found at https://warcraftratings.com/attune


INSTALLATION:
  - Copy the "Attune" folder into your Wow Classic \Interface\AddOns\ folder
  - Restart World of Warcraft Classic
 
  
HOW TO ACTIVATE:
  Just type '/attune' in chat to display your progress. 
  If you want to share this progress with the community, click the "export" button. 
  This will open a window with an encoded string you can copy to your clipboard
  The data can then be uploaded at https://warcraftratings.com/attune/upload for sharing/updating/etc

  To survey the progress of your guild, click the "survey" button to collect the information.
	You will then receive progress data from any guild member with the addon.
	Once you have enough information, click the "export" button to upload the guild progress.
  (For this to work, guildies will need the addon too)



CONTACT:
  Join the discord server to have a say in the direction of the addon
  Submit bugs/suggestions/comments here: https://discord.gg/MpfDeBZ


May the Earth Mother protect you all.
https://warcraftratings.com
Cixi@Remulos (Classic Oceanic server)
  
  
