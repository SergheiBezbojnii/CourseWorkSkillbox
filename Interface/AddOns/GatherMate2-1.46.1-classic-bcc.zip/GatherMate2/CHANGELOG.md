# GatherMate2

## [1.46.1-classic](https://github.com/Nevcairiel/GatherMate2/tree/1.46.1-classic) (2020-12-01)
[Full Changelog](https://github.com/Nevcairiel/GatherMate2/compare/1.46.0-classic...1.46.1-classic) [Previous Releases](https://github.com/Nevcairiel/GatherMate2/releases)

- Cleanup  
- Make rareNodes available to the core directly  
- Use new AddNodeChecked from the collector  
- Perform duplicate/rare check on nodes received from sync  
- Fix "Only when Tracking" display mode on BCC  
