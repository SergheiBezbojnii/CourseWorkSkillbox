local L = LibStub("AceLocale-3.0"):NewLocale("NovaWorldBuffs", "itIT");
if (not L) then
	return;
end

--Rend buff aura name.
--L["Warchief's Blessing"] = "";
--Onyxia and Nefarian buff aura name.
--L["Rallying Cry of the Dragonslayer"] = "";
--Songflower buff aura name from felwood.
--L["Songflower Serenade"] = "";

---=====---
---Horde---
---=====---

--Horde Orgrimmar Rend buff NPC.
--L["Thrall"] = "";
--Horde The Barrens Rend buff NPC.
--L["Herald of Thrall"] = "";
--Horde rend buff NPC first yell string (part of his first yell msg before before buff).
--L["Rend Blackhand, has fallen"] = "";
--Horde rend buff NPC second yell string (part of his second yell msg before before buff).
--L["Be bathed in my power"] = "";

--Horde Onyxia buff NPC.
--L["Overlord Runthak"] = "";
--Horde Onyxia buff NPC first yell string (part of his first yell msg before before buff).
--L["Onyxia, has been slain"] = "";
--Horde Onyxia buff NPC second yell string (part of his second yell msg before before buff).
--L["Be lifted by the rallying cry"] = "";

--Horde Nefarian buff NPC.
--L["High Overlord Saurfang"] = "";
--Horde Nefarian buff NPC first yell string (part of his first yell msg before before buff).
--L["NEFARIAN IS SLAIN"] = "";
--Horde Nefarian buff NPC second yell string (part of his second yell msg before before buff).
--L["Revel in his rallying cry"] = "";

---========---
---Alliance---
---========---

--Alliance Onyxia buff NPC.
--L["Major Mattingly"] = "";
--Alliance Onyxia buff NPC first yell string (part of his first yell msg before before buff).
--L["history has been made"] = "";
--Alliance Onyxia buff NPC second yell string (part of his second yell msg before before buff).
--L["Onyxia, hangs from the arches"] = "";


--Alliance Nefarian buff NPC.
--L["Field Marshal Afrasiabi"] = "";
--L["Field Marshal Stonebridge"] = "Field Marshal Stonebridge";
--Alliance Nefarian buff NPC first yell string (part of his first yell msg before before buff).
--L["the Lord of Blackrock is slain"] = "";
--Alliance Nefarian buff NPC second yell string (part of his second yell msg before before buff).
--L["Revel in the rallying cry"] = "";