--Nova World Buffs--
Classic WoW world buff timers and pre warnings.
Novaspark-Arugal OCE (classic).
https://www.curseforge.com/members/venomisto/projects

--What it does--
Warning msgs in chat window, middle of the screen, and guild chat.
Warnings for each channel and time left can be turned on and off with /wb config.
Current warning times are 30/15/10/5/1 minutes left until buff reset.
Guild msgs are configured so only 1 person online at a time will send warning msgs to avoid spam.
Guild chat is notified if a buff NPC is killed infront of a member with the addon installed (mind control reset).
Any guild member can type !wb in guild chat to display all timers.
Display timers to yourself by typing /wb.
Display timers to any channel by typing /wb <channelname> Example: /wb party or /wb say.
Display timers automatically when you log on.

--Data Syncing--
Syncs to guild at logon and when another player logs on.
Syncs when joining a group to everyone in the group.
Syncs server wide between addon users that meet each other in the world and then syncs that info with your guild.
Syncs to "yell" at logon and when changing zones (so hearthing/portals etc to crowded areas will sync to all there).
Syncs to "yell" periodically to spread data around the server.
For more reliability this addon also checks other world buff addon communications to get timers if guild members have them installed (DBM, WBT, FADE).


Note: Server restarts will cause the timers to be inaccurate for a short time because the NPC's reset.