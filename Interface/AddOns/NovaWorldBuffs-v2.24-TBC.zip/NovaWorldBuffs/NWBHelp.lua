-------------------------
---NovaWorldBuffs Help---
-------------------------

--Unfinished, coming soon.
local addonName, addon = ...;
local NWB = addon.a;
local help = {

}