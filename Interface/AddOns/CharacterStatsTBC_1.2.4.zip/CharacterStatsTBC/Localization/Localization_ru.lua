if GetLocale() ~= "ruRU" then return end

-- Translate the strings here
CSC_DEFENSE                 = DEFENSE;
CSC_WEAPON_SKILLS_HEADER    = "Оружейные навыки";
CSC_WEAPON_AXE1H_TXT        = "Топор";
CSC_WEAPON_AXE2H_TXT        = "Двуручный Топор";
CSC_WEAPON_MACE1H_TXT       = "Дробящее";
CSC_WEAPON_MACE2H_TXT       = "Двуручное Дробящее";
CSC_WEAPON_POLEARM_TXT      = "Древковое";
CSC_WEAPON_SWORD1H_TXT      = "Меч";
CSC_WEAPON_SWORD2H_TXT      = "Двуручный Меч";
CSC_WEAPON_STAFF_TXT        = "Посох";
CSC_WEAPON_UNARMED_TXT      = "Кистевое оружие";
CSC_WEAPON_DAGGER_TXT       = "Кинжал";
CSC_WEAPON_BOW_TXT          = "Лук";
CSC_WEAPON_CROSSBOW_TXT     = "Арбалет";
CSC_WEAPON_GUN_TXT          = "Огнестрельное";
CSC_HIT_BIZNICKS_TXT        = "к рейтингу меткости";

CSC_SPELL_HIT_TOOLTIP_TXT       = "Шанс попадания заклинания от снаряжения: %d%%";
CSC_SPELL_HIT_TOOLTIP_2_TXT     = "Шанс попадания заклинания (Снаряжение и Таланты): %d%%";
CSC_SPELL_HIT_SUBTOOLTIP_TXT    = "Шанс попадания заклинания (Снаряжение + Таланты):";
CSC_ARCANE_SPELL_HIT_TXT        = "Попадание чародейского заклинания";
CSC_FIRE_SPELL_HIT_TXT          = "Попадание огненного заклинания";
CSC_FROST_SPELL_HIT_TXT         = "Попадание ледяного заклинания";
CSC_DESTRUCTION_SPELL_HIT_TXT   = "Попадание заклинанием Разрушения";
CSC_AFFLICTION_SPELL_HIT_TXT    = "Попадание заклинанием Колдовства";

CSC_LIGHTNING_TXT = "Молния";
