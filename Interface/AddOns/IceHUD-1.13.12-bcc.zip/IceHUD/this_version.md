# Changelog

v1.13.12:

- Hide IceHUD during Zereth Mortis puzzles
- Fixed default player and target frames coming back sometimes (github issue #19)
- Updated TOC for 9.2.0 and 1.14.2
