# <DBM> Outlands

## [2.5.33](https://github.com/DeadlyBossMods/DBM-TBC-Classic/tree/2.5.33) (2022-04-06)
[Full Changelog](https://github.com/DeadlyBossMods/DBM-TBC-Classic/compare/2.5.32...2.5.33) [Previous Releases](https://github.com/DeadlyBossMods/DBM-TBC-Classic/releases)

- prep new tbc tag for the ZA fix  
- Update localization.tw.lua (#112)  
- bump alpha  
- prep new retail tag  
- Fixed ZA options variables so they actually save correctly now  
- Add another DC failsafe to extremely niche situations  
- Bump alphas  
