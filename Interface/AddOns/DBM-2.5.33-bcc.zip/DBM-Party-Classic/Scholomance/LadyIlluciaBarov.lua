local mod	= DBM:NewMod("LadyIlluciaBarov", "DBM-Party-Classic", 13)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20210401042132")
mod:SetCreatureID(10502)

mod:RegisterCombat("combat")
