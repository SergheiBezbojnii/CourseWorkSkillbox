---@class QuestieNPCBlacklist
local QuestieNPCBlacklist = QuestieLoader:CreateModule("QuestieNPCBlacklist")

function QuestieNPCBlacklist:Load()
    return {
    }
end
